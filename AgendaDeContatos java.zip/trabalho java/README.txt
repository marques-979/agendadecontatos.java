Nome(s) e Matrículas:
- Francisco Jonatan Sousa Silva  — 01846352
- Nádia Emilie Nogueira Lima   — 01826424
- Eduardo Rodrigues Brito      — 01814065
- Ismael Costa Marques         — 01822068

Projeto: Agenda de Contatos (Java)

Compilar:
1. Abra um terminal na pasta do projeto (onde está a pasta `src`).
2. Execute:

   javac -d bin src\\app\\*.java

Executar:
1. Após compilar, execute o programa com:

   java -cp bin app.AgendaApp

Observações:
- Os arquivos fonte estão em `src/app` e pertencem ao pacote `app`.
- Substitua os campos de nome e matrícula acima pelos dados dos participantes.
- Comentários importantes foram adicionados nas linhas que usam entrada, saída, estruturas
  de controle e operações lógicas/aritméticas para facilitar a leitura.
